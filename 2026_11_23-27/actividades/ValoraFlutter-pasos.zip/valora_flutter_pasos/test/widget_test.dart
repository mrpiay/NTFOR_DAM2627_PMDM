// Pruebas de la pantalla, sin Internet: se dibuja con datos de ejemplo
// y se comprueba lo que sale.
import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:valora_flutter/main.dart';
import 'package:valora_flutter/valoracion.dart';

// Tres valoraciones de ejemplo: un 4, un 5 y un 3
final evaluacion = Evaluacion(1, [
  Valoracion(id: 1, nota: 4),
  Valoracion(id: 2, nota: 5),
  Valoracion(id: 3, nota: 3),
]);

// Una app con las mismas rutas que ValoraApp, pero la primera pantalla
// es el resumen de la evaluación de ejemplo, sin descargar nada
Widget appDePrueba() {
  return MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => Scaffold(body: ResumenEvaluacion(evaluacion)),
      '/nota': (context) => const PantallaNota(),
    },
  );
}

void main() {
  testWidgets('El resumen muestra la media, el total y el recuento', (
    tester,
  ) async {
    // pumpWidget dibuja el widget, como en la app real
    await tester.pumpWidget(appDePrueba());

    expect(find.text('4.0'), findsOneWidget); // la media: (4 + 5 + 3) / 3
    expect(find.text('3 valoraciones'), findsOneWidget);
    expect(
      find.byType(FilaRecuento),
      findsNWidgets(5),
    ); // una fila por nota, de la 5 a la 1
  });

  testWidgets('Al tocar la fila del 5 se ven las valoraciones con un 5', (
    tester,
  ) async {
    await tester.pumpWidget(appDePrueba());

    // La fila de la nota 5, y un toque en ella
    final fila5 = find.byWidgetPredicate(
      (w) => w is FilaRecuento && w.nota == 5,
    );
    await tester.tap(fila5);
    // pumpAndSettle espera a que termine la animación de cambio de pantalla
    await tester.pumpAndSettle();

    expect(find.text('Nota 5 · 1ª evaluación'), findsOneWidget);
    expect(find.text('Valoración 2'), findsOneWidget); // la única con un 5
    expect(find.byType(ListTile), findsOneWidget);
  });
}
