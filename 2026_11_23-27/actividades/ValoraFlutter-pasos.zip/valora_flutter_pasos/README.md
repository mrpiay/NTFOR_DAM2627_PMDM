# ValoraFlutter, paso a paso

El proyecto ValoraFlutter con los pasos 1 a 3 de la guía ya hechos (el proyecto creado, la librería `http`, el permiso de Internet y los dos archivos de ValoraDart en `lib`) y, en la carpeta `pasos`, `main.dart` tal como queda al final de cada uno de los pasos 4 a 10, en los que se construye la pantalla.

| Archivo | Qué es |
|---|---|
| `lib/main.dart` | El del paso 4: la app más pequeña |
| `lib/servicio_valora.dart` y `lib/valoracion.dart` | La descarga y las clases de ValoraDart, sin cambios |
| `pasos/paso4.dart` … `pasos/paso10.dart` | `main.dart` al final de cada paso. El del paso 10 es el definitivo. VS Code no los analiza (`analysis_options.yaml` excluye la carpeta): fuera de `lib` darían errores, porque no encuentran los archivos de ValoraDart |

## Cómo se usa

1. Descomprime el zip en `C:\dam2627\pmdm` y, en la terminal:

   ```powershell
   cd C:\dam2627\pmdm\valora_flutter_pasos
   flutter pub get
   code .
   ```

2. Arranca el emulador (`flutter emulators --launch Pixel_9`), abre `lib/main.dart` y pulsa **Run**, encima de `void main()`.
3. Para ver un paso, abre su archivo en `pasos` (por ejemplo, `paso5.dart`), copia todo (`Ctrl + A` y `Ctrl + C`), pégalo en `lib/main.dart` en lugar de lo que había (`Ctrl + A` y `Ctrl + V`) y guarda (`Ctrl + S`). Con la app en marcha, el *hot reload* la actualiza al momento.
4. Con cada paso, lee su apartado de la guía y compara el código con el del paso anterior: qué se ha añadido y por qué.

- En el paso 10, y siempre que se vuelva a un paso anterior, hay que reiniciar la app con *hot restart* (`Ctrl + Mayús + F5`).
