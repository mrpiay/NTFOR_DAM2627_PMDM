package com.example.valora_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
