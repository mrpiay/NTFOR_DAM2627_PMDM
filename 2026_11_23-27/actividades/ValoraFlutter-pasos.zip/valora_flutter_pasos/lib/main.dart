// ValoraFlutter: las valoraciones de PMDM de cada evaluación, en una app de Flutter.
// Es ValoraPMDM hecha con Flutter: los mismos datos y la misma pantalla, y una segunda
// pantalla con las valoraciones de una nota. Las clases y la descarga son las de ValoraDart, sin cambios.
import 'package:material_ui/material_ui.dart';

void main() {
  runApp(const ValoraApp());
}

// ── La app: sin estado, el tema y la pantalla de inicio ──────────────
class ValoraApp extends StatelessWidget {
  const ValoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ValoraFlutter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      ),
      // La pantalla de inicio: una barra arriba y un texto en el centro
      home: Scaffold(
        appBar: AppBar(title: const Text('Valoraciones de PMDM')),
        body: const Center(child: Text('Aquí irán las valoraciones')),
      ),
    );
  }
}
