// Las clases de ValoraDart: una valoración y las valoraciones de una evaluación.
// Aquí no se descarga ni se escribe nada: solo datos y cálculos.

/// Una valoración: un número para distinguirla y una nota del 1 al 5.
/// Es lo que hay en cada elemento de los archivos JSON: { "id": 1, "nota": 4 }
class Valoracion {
  final int id;
  final int nota;

  // Constructor con argumentos con nombre y obligatorios (required)
  Valoracion({required this.id, required this.nota});

  // Constructor con nombre: crea la valoración a partir de un mapa, el JSON ya leído.
  // Las propiedades se inicializan después de los dos puntos, separadas por comas
  Valoracion.fromJson(Map<String, dynamic> json)
      : id = json['id'] as int,
        nota = json['nota'] as int;

  // Lo que se escribe al hacer print(valoracion)
  @override
  String toString() => 'Valoración $id: $nota';
}

/// Las valoraciones de una evaluación y lo que se calcula con ellas
class Evaluacion {
  final int numero;
  final List<Valoracion> valoraciones;

  // Constructor simplificado: los argumentos van directamente a las propiedades
  Evaluacion(this.numero, this.valoraciones);

  // Getter: se usa como una propiedad (evaluacion.total), pero se calcula
  int get total => valoraciones.length;

  // La media, o null si no hay valoraciones: por eso el tipo es double? (nullable)
  double? get media {
    if (valoraciones.isEmpty) {
      return null;
    }
    // map convierte cada valoración en su nota; reduce las suma de dos en dos
    final suma = valoraciones.map((v) => v.nota).reduce((a, b) => a + b);
    return suma / total;
  }

  // Cuántas veces se ha dado cada nota, de la 5 a la 1: {5: 3, 4: 6, 3: 3, 2: 1, 1: 0}
  Map<int, int> get recuento {
    final veces = {5: 0, 4: 0, 3: 0, 2: 0, 1: 0};
    for (final valoracion in valoraciones) {
      veces[valoracion.nota] = veces[valoracion.nota]! + 1;
    }
    return veces;
  }
}

/// Cinco caracteres: un * por cada estrella y un - por cada una que falta.
/// Las estrellas son la media redondeada a un entero: 3.8 → "****-"
String estrellas(double media) {
  final llenas = media.round();
  return '*' * llenas + '-' * (5 - llenas);
}
