// La descarga de las valoraciones, con el paquete http.
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'valoracion.dart';

/// La carpeta de GitHub con los archivos valora1.json, valora2.json…
/// Son las mismas valoraciones de ejemplo que usa ValoraPMDM
const urlBase =
    'https://raw.githubusercontent.com/mrpiay/NTFOR_DAM2627_PMDM/main/valora/ejemplo/';

/// Descarga las valoraciones de una evaluación.
/// Es asíncrona: devuelve un Future, que se resuelve cuando llega la respuesta.
/// El resultado es la lista de valoraciones, o null si el archivo no existe (404)
Future<List<Valoracion>?> descargar(int evaluacion) async {
  final url = Uri.parse('${urlBase}valora$evaluacion.json');
  // await: espera a que llegue la respuesta del servidor antes de seguir
  final respuesta = await http.get(url);

  if (respuesta.statusCode == 404) {
    return null; // esa evaluación aún no tiene archivo
  }
  if (respuesta.statusCode != 200) {
    throw Exception('error del servidor (${respuesta.statusCode})');
  }

  // jsonDecode convierte el texto JSON en objetos de Dart: aquí, una lista de mapas
  final lista = jsonDecode(respuesta.body) as List;
  // Cada mapa se convierte en una Valoracion con el constructor fromJson
  return lista
      .map((elemento) => Valoracion.fromJson(elemento as Map<String, dynamic>))
      .toList();
}
