// ValoraFlutter: las valoraciones de PMDM de cada evaluación, en una app de Flutter.
// Es ValoraPMDM hecha con Flutter: los mismos datos y la misma pantalla, y una segunda
// pantalla con las valoraciones de una nota. Las clases y la descarga son las de ValoraDart, sin cambios.
import 'package:material_ui/material_ui.dart';

import 'servicio_valora.dart';
import 'valoracion.dart';

void main() {
  runApp(const ValoraApp());
}

// ── La app: sin estado, el tema y la pantalla de inicio ──────────────
class ValoraApp extends StatelessWidget {
  const ValoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ValoraFlutter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      ),
      home: const PantallaValora(),
    );
  }
}

// ── La pantalla: con estado, porque las valoraciones se descargan ─────
class PantallaValora extends StatefulWidget {
  const PantallaValora({super.key});

  @override
  State<PantallaValora> createState() => _PantallaValoraState();
}

class _PantallaValoraState extends State<PantallaValora> {
  // El estado: la descarga en curso o terminada. Es un Future: aún puede no haber llegado
  late Future<List<Evaluacion>> _carga;

  // initState se ejecuta una sola vez, al crear la pantalla: empieza la primera descarga
  @override
  void initState() {
    super.initState();
    _carga = cargarEvaluaciones();
  }

  // Descarga las tres evaluaciones y se queda con las que tienen archivo
  Future<List<Evaluacion>> cargarEvaluaciones() async {
    final evaluaciones = <Evaluacion>[];
    for (var numero = 1; numero <= 3; numero++) {
      final valoraciones = await descargar(numero);
      if (valoraciones != null) {
        evaluaciones.add(Evaluacion(numero, valoraciones));
      }
    }
    return evaluaciones;
  }

  // El botón de recargar: una descarga nueva. setState avisa a Flutter para que redibuje
  void recargar() {
    setState(() {
      _carga = cargarEvaluaciones();
    });
  }

  @override
  Widget build(BuildContext context) {
    // FutureBuilder dibuja una cosa u otra según cómo vaya el Future
    return FutureBuilder<List<Evaluacion>>(
      future: _carga,
      builder: (context, snapshot) {
        // 1. Aún no ha terminado: un círculo de progreso
        if (snapshot.connectionState != ConnectionState.done) {
          return pantalla(
            cuerpo: const Center(child: CircularProgressIndicator()),
          );
        }
        // 2. Ha fallado (sin conexión, error del servidor): el motivo
        if (snapshot.hasError) {
          return pantalla(
            cuerpo: Aviso(
              'No se han podido descargar las valoraciones.\n${snapshot.error}',
            ),
          );
        }
        // 3. Ha terminado bien: las evaluaciones con archivo
        final evaluaciones = snapshot.data!;
        if (evaluaciones.isEmpty) {
          return pantalla(
            cuerpo: const Aviso('No hay valoraciones publicadas.'),
          );
        }
        // Una pestaña por evaluación. DefaultTabController une las pestañas con su contenido
        return DefaultTabController(
          length: evaluaciones.length,
          child: pantalla(
            pestanas: TabBar(
              tabs: [
                for (final e in evaluaciones)
                  Tab(text: '${e.numero}ª evaluación'),
              ],
            ),
            cuerpo: TabBarView(
              children: [for (final e in evaluaciones) ResumenEvaluacion(e)],
            ),
          ),
        );
      },
    );
  }

  // La estructura de la pantalla, igual en todos los casos: la barra de arriba, con
  // el título y el botón de recargar, las pestañas (si las hay) y el contenido
  Widget pantalla({PreferredSizeWidget? pestanas, required Widget cuerpo}) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Valoraciones de PMDM'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Recargar las valoraciones',
            onPressed: recargar,
          ),
        ],
        bottom: pestanas,
      ),
      body: cuerpo,
    );
  }
}

// ── Un aviso centrado: sin valoraciones, o un error ────────────────────
class Aviso extends StatelessWidget {
  final String texto;

  const Aviso(this.texto, {super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(texto, textAlign: TextAlign.center),
      ),
    );
  }
}

// ── El contenido de una pestaña: la media, sus estrellas y el recuento ─
class ResumenEvaluacion extends StatelessWidget {
  final Evaluacion evaluacion;

  const ResumenEvaluacion(this.evaluacion, {super.key});

  @override
  Widget build(BuildContext context) {
    final media = evaluacion.media!; // en una pestaña siempre hay valoraciones
    final total = evaluacion.total;
    // ListView: si no cabe (por ejemplo, con el móvil girado), se desplaza
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: Text(
            media.toStringAsFixed(1),
            style: Theme.of(context).textTheme.displayMedium,
          ),
        ),
        Center(child: Estrellas(media.round())),
        Center(
          child: Text(total == 1 ? '1 valoración' : '$total valoraciones'),
        ),
        const Divider(height: 32),
        // Una fila por nota, de la 5 a la 1: el for dentro de la lista crea un widget por cada una
        for (final nota in evaluacion.recuento.keys)
          FilaRecuento(evaluacion: evaluacion, nota: nota),
      ],
    );
  }
}

// ── Cinco estrellas: las primeras, del color del tema; el resto, en gris ──
class Estrellas extends StatelessWidget {
  final int llenas;

  const Estrellas(this.llenas, {super.key});

  @override
  Widget build(BuildContext context) {
    final colores = Theme.of(context).colorScheme;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          Icon(
            Icons.star,
            color: i <= llenas ? colores.primary : colores.outlineVariant,
          ),
      ],
    );
  }
}

// ── Una fila del recuento: la nota, su barra y cuántas veces se ha dado ──
class FilaRecuento extends StatelessWidget {
  final Evaluacion evaluacion;
  final int nota;

  const FilaRecuento({super.key, required this.evaluacion, required this.nota});

  @override
  Widget build(BuildContext context) {
    final veces = evaluacion.recuento[nota]!;
    final total = evaluacion.total;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(width: 20, child: Text('$nota')),
          Icon(Icons.star, color: Theme.of(context).colorScheme.primary),
          // Expanded: la barra ocupa todo el ancho que dejan el número y la estrella
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              // La parte llena de la barra: la proporción de esa nota, de 0 a 1
              child: LinearProgressIndicator(
                value: veces / total,
                minHeight: 12,
              ),
            ),
          ),
          SizedBox(width: 28, child: Text('$veces')),
        ],
      ),
    );
  }
}
