// ValoraFlutter: las valoraciones de PMDM de cada evaluación, en una app de Flutter.
// Es ValoraPMDM hecha con Flutter: los mismos datos y la misma pantalla, y una segunda
// pantalla con las valoraciones de una nota. Las clases y la descarga son las de ValoraDart, sin cambios.
import 'package:material_ui/material_ui.dart';

import 'servicio_valora.dart';
import 'valoracion.dart';

void main() {
  runApp(const ValoraApp());
}

// ── La app: sin estado, el tema y la pantalla de inicio ──────────────
class ValoraApp extends StatelessWidget {
  const ValoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ValoraFlutter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      ),
      home: const PantallaValora(),
    );
  }
}

// ── La pantalla: con estado, porque las valoraciones se descargan ─────
class PantallaValora extends StatefulWidget {
  const PantallaValora({super.key});

  @override
  State<PantallaValora> createState() => _PantallaValoraState();
}

class _PantallaValoraState extends State<PantallaValora> {
  // El estado: la descarga en curso o terminada. Es un Future: aún puede no haber llegado
  late Future<List<Evaluacion>> _carga;

  // initState se ejecuta una sola vez, al crear la pantalla: empieza la primera descarga
  @override
  void initState() {
    super.initState();
    _carga = cargarEvaluaciones();
  }

  // Descarga las tres evaluaciones y se queda con las que tienen archivo
  Future<List<Evaluacion>> cargarEvaluaciones() async {
    final evaluaciones = <Evaluacion>[];
    for (var numero = 1; numero <= 3; numero++) {
      final valoraciones = await descargar(numero);
      if (valoraciones != null) {
        evaluaciones.add(Evaluacion(numero, valoraciones));
      }
    }
    return evaluaciones;
  }

  // El botón de recargar: una descarga nueva. setState avisa a Flutter para que redibuje
  void recargar() {
    setState(() {
      _carga = cargarEvaluaciones();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Valoraciones de PMDM'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Recargar las valoraciones',
            onPressed: recargar,
          ),
        ],
      ),
      // FutureBuilder dibuja una cosa u otra según cómo vaya el Future
      body: FutureBuilder<List<Evaluacion>>(
        future: _carga,
        builder: (context, snapshot) {
          // 1. Aún no ha terminado: un círculo de progreso
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          // 2. Ha fallado (sin conexión, error del servidor): el motivo
          if (snapshot.hasError) {
            return Aviso(
              'No se han podido descargar las valoraciones.\n${snapshot.error}',
            );
          }
          // 3. Ha terminado bien: las evaluaciones con archivo
          final evaluaciones = snapshot.data!;
          if (evaluaciones.isEmpty) {
            return const Aviso('No hay valoraciones publicadas.');
          }
          // De momento, una línea por evaluación
          return Column(
            children: [
              for (final e in evaluaciones)
                Text(
                  '${e.numero}ª evaluación: ${e.total} valoraciones, '
                  'media ${e.media!.toStringAsFixed(1)}',
                ),
            ],
          );
        },
      ),
    );
  }
}

// ── Un aviso centrado: sin valoraciones, o un error ────────────────────
class Aviso extends StatelessWidget {
  final String texto;

  const Aviso(this.texto, {super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(texto, textAlign: TextAlign.center),
      ),
    );
  }
}
