package com.example.valorapmdm

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

// ── Las pantallas de la app y cómo se pasa de una a otra (paso 14) ─────
@Composable
fun NavegacionValora() {
    // El controlador de navegación: sabe en qué pantalla se está y guarda la pila de las anteriores
    val navController = rememberNavController()

    // Un solo ViewModel para las dos pantallas: se crea fuera del NavHost, y así
    // la pantalla de una nota ve las mismas valoraciones y la misma pestaña elegida
    val viewModel: ValoraViewModel = viewModel()

    // NavHost: cada composable(ruta) es una pantalla. La primera es "resumen"
    NavHost(navController = navController, startDestination = "resumen") {
        composable("resumen") {
            PantallaValora(
                viewModel = viewModel,
                // Al tocar una fila, se va a la ruta de esa nota: "nota/5"
                onNota = { nota -> navController.navigate("nota/$nota") }
            )
        }
        // {nota} es un argumento: la parte de la ruta que cambia
        composable("nota/{nota}") { entrada ->
            val nota = entrada.arguments?.getString("nota")?.toIntOrNull() ?: 0
            PantallaNota(
                viewModel = viewModel,
                nota = nota,
                // Volver: quita esta pantalla de la pila y se ve la anterior
                onVolver = { navController.popBackStack() }
            )
        }
    }
}
