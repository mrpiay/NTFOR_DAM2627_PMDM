package com.example.valorapmdm

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ValoraDao {

    // ── Leer ─────────────────────────────────────────────────────────
    // Todas las valoraciones guardadas, ordenadas.
    // Devuelve un Flow: cada vez que la tabla cambia, envía la lista nueva
    // y la pantalla se actualiza sola
    @Query("SELECT * FROM valora ORDER BY evaluacion, id")
    fun todas(): Flow<List<Valora>>

    // ── Escribir ─────────────────────────────────────────────────────
    // suspend: tarda, así que se llama desde una corrutina, fuera del hilo principal
    @Query("DELETE FROM valora WHERE evaluacion = :evaluacion")
    suspend fun borrarEvaluacion(evaluacion: Int)

    @Insert
    suspend fun insertar(lista: List<Valora>)

    // Sustituye las valoraciones de una evaluación por las recién descargadas.
    // @Transaction: o se hacen las dos cosas, o ninguna. Si fallara la inserción,
    // no se quedaría la evaluación borrada
    @Transaction
    suspend fun sustituir(evaluacion: Int, lista: List<Valora>) {
        borrarEvaluacion(evaluacion)
        insertar(lista)
    }
}
