package com.example.valorapmdm

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.SerializationException
import retrofit2.HttpException
import java.io.IOException

class ValoraViewModel(application: Application) : AndroidViewModel(application) {

    // ── Las fuentes de datos ─────────────────────────────────────────
    private val dao = ValoraDatabase.obtener(application).valoraDao()

    // Lo que no viene de Room: la pestaña elegida, si está cargando y el aviso
    private val pantalla = MutableStateFlow(ValoraUiState())

    // ── El estado que ve la pantalla ─────────────────────────────────
    // Junta lo guardado en Room con lo de la interfaz. Cuando cambia cualquiera
    // de los dos, se vuelve a calcular
    val uiState: StateFlow<ValoraUiState> =
        combine(dao.todas(), pantalla) { guardadas, p ->
            p.copy(porEvaluacion = guardadas.groupBy { it.evaluacion })
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ValoraUiState())

    // ── Acciones de la pantalla ──────────────────────────────────────
    // Al tocar una pestaña
    fun elegir(evaluacion: Int) {
        pantalla.update { it.copy(seleccionada = evaluacion) }
    }

    // Al pulsar el botón de recargar: pide las tres evaluaciones y deja en Room
    // lo que hay publicado. Al abrir la app no se llama: se muestra lo guardado
    fun cargar() {
        // Si ya se está descargando, no se empieza otra descarga
        if (pantalla.value.cargando) return
        pantalla.update { it.copy(cargando = true, aviso = null) }

        // Una corrutina: las peticiones tardan y no pueden bloquear el hilo principal
        viewModelScope.launch {
            try {
                for (evaluacion in 1..3) {
                    try {
                        val lista = Red.servicio.valora(evaluacion)
                        // Del JSON a la tabla (aValora, en Valora.kt) y se guarda
                        dao.sustituir(evaluacion, lista.map { it.aValora(evaluacion) })
                        Log.d("ValoraPMDM", "Evaluación $evaluacion: ${lista.size} valoraciones")
                    } catch (e: HttpException) {
                        // Solo el 404 (el archivo no existe) quiere decir «sin valoraciones publicadas».
                        // Cualquier otro código es un error del servidor: se trata más abajo
                        if (e.code() != 404) throw e
                        // Si había valoraciones guardadas de esa evaluación, ya no están publicadas
                        dao.borrarEvaluacion(evaluacion)
                        Log.d("ValoraPMDM", "Evaluación $evaluacion: sin archivo (404)")
                    }
                }
            } catch (e: IOException) {
                // No hubo respuesta: no hay conexión o no se encuentra el servidor
                avisar("Sin conexión", e)
            } catch (e: HttpException) {
                // El servidor respondió con un error que no es 404 (403, 500…)
                avisar("Error del servidor (${e.code()})", e)
            } catch (e: SerializationException) {
                // Llegó el archivo, pero su contenido no es el JSON esperado
                avisar("Los datos descargados no tienen el formato esperado", e)
            } finally {
                // Siempre, haya ido bien o mal: se quita la barra de progreso
                pantalla.update { it.copy(cargando = false) }
            }
        }
    }

    // Escribe el error en Logcat y lo avisa en la pantalla. Lo guardado en Room no se toca
    private fun avisar(motivo: String, e: Exception) {
        Log.e("ValoraPMDM", motivo, e)
        pantalla.update { it.copy(aviso = "$motivo: se muestran las valoraciones guardadas") }
    }
}
