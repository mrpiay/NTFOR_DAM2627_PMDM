package com.example.valorapmdm

import androidx.room.Entity
import kotlinx.serialization.Serializable

// ── Lo que llega en el JSON ──────────────────────────────────────────
// Cada objeto del archivo: { "id": 1, "nota": 4 }
// Los nombres de las propiedades tienen que ser los mismos que en el JSON
@Serializable
data class ValoraJson(
    val id: Int,
    val nota: Int
)

// ── Lo que se guarda en Room ─────────────────────────────────────────
// Lo mismo y, además, de qué evaluación es (en el JSON lo dice el nombre del archivo).
// La clave primaria son dos columnas: la valoración 1 de la 1ª evaluación
// no es la misma que la valoración 1 de la 2ª
@Entity(tableName = "valora", primaryKeys = ["evaluacion", "id"])
data class Valora(
    val evaluacion: Int,
    val id: Int,
    val nota: Int
)

// ── De lo que llega a lo que se guarda ───────────────────────────────
// Convierte una valoración del JSON en una fila de la tabla, añadiéndole su evaluación
fun ValoraJson.aValora(evaluacion: Int) = Valora(evaluacion = evaluacion, id = id, nota = nota)
