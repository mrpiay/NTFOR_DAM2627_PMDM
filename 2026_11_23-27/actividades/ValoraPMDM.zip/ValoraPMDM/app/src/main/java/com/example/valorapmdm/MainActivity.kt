package com.example.valorapmdm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.valorapmdm.ui.theme.ValoraPMDMTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()  // la app ocupa toda la pantalla, también detrás de las barras del sistema
        setContent {
            // El tema (colores y letras) que creó Android Studio, en ui.theme
            ValoraPMDMTheme {
                // Las dos pantallas y cómo se pasa de una a otra (Navegacion.kt, paso 14)
                NavegacionValora()
            }
        }
    }
}
