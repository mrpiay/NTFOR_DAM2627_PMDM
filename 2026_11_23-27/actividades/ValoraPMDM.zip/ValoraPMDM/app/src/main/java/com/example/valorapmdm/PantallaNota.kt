package com.example.valorapmdm

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

// ── La pantalla de una nota: las valoraciones que la tienen (paso 15) ──
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaNota(viewModel: ValoraViewModel, nota: Int, onVolver: () -> Unit) {
    val estado by viewModel.uiState.collectAsStateWithLifecycle()
    val valoraciones = estado.conNota(nota)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nota $nota · ${estado.mostrada}ª evaluación") },
                // La flecha de volver, a la izquierda del título
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { innerPadding ->
        // LazyColumn: una lista que solo dibuja las filas que se ven
        LazyColumn(modifier = Modifier.padding(innerPadding)) {
            items(valoraciones) { valoracion ->
                // ListItem: una fila estándar de Material, con icono, título y subtítulo
                ListItem(
                    leadingContent = { Icon(Icons.Filled.Person, contentDescription = null) },
                    headlineContent = { Text("Valoración ${valoracion.id}") },
                    supportingContent = { Text("${valoracion.nota} de 5") }
                )
            }
        }
    }
}
