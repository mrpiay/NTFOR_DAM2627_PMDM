package com.example.valorapmdm

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

// ── La pantalla completa ─────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
// onNota: lo que se hace al tocar una fila del recuento (paso 15). Lo decide quien la usa: la navegación
fun PantallaValora(viewModel: ValoraViewModel = viewModel(), onNota: (Int) -> Unit = {}) {
    // El estado del ViewModel. Cuando cambia, esta función se vuelve a ejecutar
    val estado by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        // La barra de arriba: el título y el botón de recargar
        topBar = {
            TopAppBar(
                title = { Text("Valoraciones de PMDM") },
                actions = {
                    // Mientras descarga, el botón está desactivado
                    IconButton(onClick = { viewModel.cargar() }, enabled = !estado.cargando) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Recargar las valoraciones")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // ── Las pestañas: una por cada evaluación con valoraciones ──
            if (estado.evaluaciones.isNotEmpty()) {
                PrimaryTabRow(selectedTabIndex = estado.indicePestana) {
                    estado.evaluaciones.forEach { evaluacion ->
                        Tab(
                            selected = evaluacion == estado.mostrada,
                            onClick = { viewModel.elegir(evaluacion) },
                            text = { Text("${evaluacion}ª evaluación") }
                        )
                    }
                }
            }

            // verticalScroll: si no cabe (por ejemplo, con el móvil girado), se desplaza hacia abajo
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // ── La barra de progreso y el aviso ─────────────────────
                if (estado.cargando) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                estado.aviso?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp))
                }

                // ── La media y el recuento ──────────────────────────────
                Resumen(mediaTexto = estado.mediaTexto, estrellas = estado.estrellas, total = estado.total)
                if (estado.total > 0) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))
                    // Para que se sepa que las filas se pueden tocar (paso 15)
                    Text(
                        "Toca una fila para ver las valoraciones con esa nota",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    // Las filas vienen ya calculadas en el estado: aquí solo se dibujan
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        for (fila in estado.filas) {
                            FilaRecuento(fila, onClick = { onNota(fila.nota) })
                        }
                    }
                }
            }
        }
    }
}

// ── La media con un decimal, sus estrellas y cuántas valoraciones hay ──
@Composable
fun Resumen(mediaTexto: String?, estrellas: Int, total: Int) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (mediaTexto == null) {
            Text("No hay valoraciones guardadas", style = MaterialTheme.typography.titleMedium)
            Text("Pulsa el botón de recargar para descargarlas", style = MaterialTheme.typography.bodyMedium)
        } else {
            Text(mediaTexto, style = MaterialTheme.typography.displayMedium)
            Estrellas(estrellas)
            // En singular si solo hay una
            Text(if (total == 1) "1 valoración" else "$total valoraciones", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ── Cinco estrellas: las primeras, del color del tema; el resto, en gris ──
@Composable
fun Estrellas(llenas: Int) {
    Row {
        repeat(5) { i ->
            Icon(
                Icons.Filled.Star,
                contentDescription = null,
                tint = if (i < llenas) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
            )
        }
    }
}

// Cuánto tarda una barra en llegar a su tamaño, en milisegundos
private const val DURACION_MS = 600

// ── Una fila del recuento: la nota, su barra y cuántas veces se ha dado ──
// La barra está animada (paso 14): al aparecer, crece desde 0; al cambiar de pestaña
// o al recargar, pasa poco a poco de su tamaño de antes al nuevo, en lugar de saltar
@Composable
// onClick: al tocar la fila. Solo responde si alguien ha puesto esa nota (paso 15)
fun FilaRecuento(fila: FilaNota, onClick: () -> Unit = {}) {
    // Al principio, la barra vacía; en cuanto la fila se dibuja por primera vez, su valor
    var mostrada by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { mostrada = true }

    // El valor que se dibuja: va del que tenía al objetivo en DURACION_MS,
    // rápido al principio y más despacio al final (FastOutSlowInEasing)
    val proporcion by animateFloatAsState(
        targetValue = if (mostrada) fila.proporcion else 0f,
        animationSpec = tween(durationMillis = DURACION_MS, easing = FastOutSlowInEasing),
        label = "barra de la nota ${fila.nota}"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = fila.veces > 0, onClick = onClick),  // con el efecto de onda de Material
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${fila.nota}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(20.dp))
        Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        // La misma barra que la de carga; la parte llena (de 0 a 1) es la animada
        LinearProgressIndicator(
            progress = { proporcion },
            modifier = Modifier
                .weight(1f)              // ocupa todo el ancho que dejan el número y la estrella
                .height(12.dp)
                .padding(horizontal = 8.dp),
            // Barra lisa: extremos rectos, sin hueco entre la parte llena y el resto, ni punto al final.
            // Con extremos redondos (los de por defecto), Material deja siempre un hueco, aunque gapSize sea 0
            strokeCap = StrokeCap.Butt,
            gapSize = 0.dp,
            drawStopIndicator = {}
        )
        Text("${fila.veces}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.width(28.dp))
    }
}
