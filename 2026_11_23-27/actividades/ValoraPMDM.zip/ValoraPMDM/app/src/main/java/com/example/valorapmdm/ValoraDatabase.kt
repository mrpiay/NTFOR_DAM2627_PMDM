package com.example.valorapmdm

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Las tablas de la base de datos y su versión (se sube si cambia la estructura)
@Database(entities = [Valora::class], version = 1)
abstract class ValoraDatabase : RoomDatabase() {

    // Room escribe el código de esta función: devuelve el DAO
    abstract fun valoraDao(): ValoraDao

    // ── Una sola base de datos para toda la app ──────────────────────
    companion object {
        @Volatile
        private var instancia: ValoraDatabase? = null

        // Si ya existe, la devuelve; si no, la crea (archivo "valora.db")
        fun obtener(context: Context): ValoraDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(context, ValoraDatabase::class.java, "valora.db")
                    .build()
                    .also { instancia = it }
            }
    }
}
