package com.example.valorapmdm

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

// ── La petición ──────────────────────────────────────────────────────
// Cada función de la interfaz es una petición; Retrofit escribe el código.
// {evaluacion} se sustituye por el número que se pasa en @Path:
//   valora(1) → GET URL_BASE + "valora1.json"
//   valora(2) → GET URL_BASE + "valora2.json"
// suspend: la respuesta tarda, así que se llama desde una corrutina
interface ServicioValora {
    @GET("valora{evaluacion}.json")
    suspend fun valora(@Path("evaluacion") evaluacion: Int): List<ValoraJson>
}

// ── Un solo objeto Retrofit para toda la app ─────────────────────────
object Red {
    // La parte común de todas las direcciones. Tiene que terminar en /
    private const val URL_BASE =
        "https://raw.githubusercontent.com/mrpiay/NTFOR_DAM2627_PMDM/main/valora/ejemplo/"

    // ignoreUnknownKeys: si el JSON trae campos que ValoraJson no tiene, se ignoran
    // en lugar de dar error
    private val json = Json { ignoreUnknownKeys = true }

    val servicio: ServicioValora = Retrofit.Builder()
        .baseUrl(URL_BASE)
        // El conversor: pasa el JSON de la respuesta a objetos ValoraJson
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(ServicioValora::class.java)
}
