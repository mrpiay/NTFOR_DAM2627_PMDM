package com.example.valorapmdm

import java.util.Locale
import kotlin.math.roundToInt

// ── Una fila del recuento, ya calculada ──────────────────────────────
// La pantalla solo la dibuja: no tiene que contar ni dividir nada
data class FilaNota(
    val nota: Int,          // de 1 a 5
    val veces: Int,         // cuántas veces se ha dado
    val proporcion: Float   // veces / total, de 0 a 1: la parte llena de la barra
)

// Todo lo que muestra la pantalla
data class ValoraUiState(
    // ── Datos guardados ──────────────────────────────────────────────
    // Las valoraciones de Room, agrupadas por evaluación: 1 → [...], 2 → [...]
    val porEvaluacion: Map<Int, List<Valora>> = emptyMap(),

    // ── Estado de la interfaz ────────────────────────────────────────
    val seleccionada: Int = 1,      // la pestaña elegida
    val cargando: Boolean = false,  // si se está descargando (barra de progreso)
    val aviso: String? = null       // el mensaje de error, si lo hay
) {
    // ── Lo que se calcula ────────────────────────────────────────────
    // Las evaluaciones que tienen valoraciones, en orden: son las pestañas
    val evaluaciones: List<Int>
        get() = porEvaluacion.keys.sorted()

    // La evaluación que se muestra: la elegida, si tiene valoraciones; si no,
    // la primera que tenga (por ejemplo, si solo hay de la 2ª). null si no hay ninguna
    val mostrada: Int?
        get() = if (seleccionada in evaluaciones) seleccionada else evaluaciones.firstOrNull()

    // La posición de la pestaña que se muestra (0, 1, 2…). -1 si no hay pestañas
    val indicePestana: Int
        get() = evaluaciones.indexOf(mostrada)

    // Las valoraciones de la evaluación que se muestra
    val lista: List<Valora>
        get() = mostrada?.let { porEvaluacion[it] }.orEmpty()

    // Cuántas valoraciones hay
    val total: Int
        get() = lista.size

    // La media de las notas. Sin valoraciones no hay media: null
    val media: Double?
        get() = if (lista.isEmpty()) null else lista.map { it.nota }.average()

    // La media como se escribe en la pantalla: con un decimal y punto decimal (3.8),
    // sea cual sea el idioma del móvil (Locale.US). null si no hay media
    val mediaTexto: String?
        get() = media?.let { String.format(Locale.US, "%.1f", it) }

    // Cuántas estrellas van de color: la media redondeada (3.8 → 4)
    val estrellas: Int
        get() = media?.roundToInt() ?: 0

    // Las valoraciones de la evaluación que se muestra con una nota (paso 15)
    fun conNota(nota: Int): List<Valora> = lista.filter { it.nota == nota }

    // El recuento, de la nota 5 a la 1: una fila por nota, también las que no ha dado nadie
    val filas: List<FilaNota>
        get() = (5 downTo 1).map { nota ->
            val veces = lista.count { it.nota == nota }
            FilaNota(
                nota = nota,
                veces = veces,
                proporcion = if (total == 0) 0f else veces.toFloat() / total
            )
        }
}
