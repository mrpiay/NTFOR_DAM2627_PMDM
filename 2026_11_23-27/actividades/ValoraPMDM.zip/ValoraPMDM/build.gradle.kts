// Archivo de compilación del proyecto: los plugins que pueden usar los módulos
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false                  // KSP, para Room
    alias(libs.plugins.kotlin.serialization) apply false // para convertir JSON
}
